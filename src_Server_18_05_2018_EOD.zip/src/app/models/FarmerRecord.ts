export class FarmerRecord {
  GvtId: number;
  LnRecId: number;
  OwnerNm: string;
  DOB: number;
  LndAddr:string;
  AreaOfLand:number;
  NoSeedReq:number;
  bank: Bank;
  preMutationSketch: string;
  isFarmerRecApproved : boolean;
  eid:number;
  constructor() { }

}

export class Bank {
  AcNo: number;
  IfscCd:string;
  PanNo:string;
  AdhrNo: number;
  MblNo: number;
  EmlId:string;
  Addr: string;
  constructor() { }
}
